/*
 * File:   main.c
 * Author: Hassan
 *
 * Created on 25 ??????, 2021, 10:06 ?
 */






#include "../inc/app.h"

void appBoot(void) {

}

void appInit(void) {

}

void appSync(void) {

}

void appMain(void) {

}
